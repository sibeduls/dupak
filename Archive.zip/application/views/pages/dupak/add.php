<style type="text/css">
    textarea.form-control {
        height: 100%;
    }
</style>
<div class="row">
<div class="col-md-8">
    <?php echo @$this->session->flashdata('item') ?> 
    <form role="form" method="POST" action="<?php echo base_url() ?>dupak/proses">
    <div class="form-group">
        <label> UNSUR </label>
        <?php
        echo '<select class="form-control" name="id_unsur" id="id_unsur" onchange="pilihunsur(this.value)">';
        echo '<option value="">-- PILIH --</option>';
        foreach ($master_unsur as $data) { 
            echo '<option value="'.$data['id_unsur'].'">'.strtoupper($data['nama_unsur']).'</option>';    
        }
        echo '</select>';
        ?>
    </div>

    <div class="form-group">
        <label> SUB UNSUR </label>
        <?php
        echo '<select class="form-control" name="id_subunsur" id="sub_unsur" onchange="pilihsubunsur(this.value)">';
        echo '<option value="">-- PILIH --</option>';
        foreach ($master_subunsur as $data) { 
            echo '<option value="'.$data['id_subunsur'].'">'.strtoupper($data['nama_subunsur']).'</option>';    
        }
        echo '</select>';
        ?>
    </div>

    <div class="form-group">
        <label> Kegiatan  </label> <br />
        <select class="js-source-states form-control" name="id_kegiatan" id="kegiatan" style="width:90%;">
        <option value=""> Pilih Sub Usur Terlebih Dahulu </option>
        </select>

    </div>

    <div class="form-group">
        <label> KODE KEGIATAN </label>
        <input type="text" name="kode_kegiatan" id="kode_kegiatan" value="" class="form-control" readonly> 
    </div>

    <div class="form-group" id="only-number">
        <label> BESARAN ANGKA KREDIT </label>
        <input type="text" name="angka_kredit" id="angka_kredit" value="" class="form-control" readonly> 
    </div>

    <div class="form-group">
        <label> SATUAN HASIL </label>
        <input type="text" name="satuan_hasil" id="satuan_hasil" value="" class="form-control" readonly> 
    </div>

    <div class="form-group">
        <label> PELAKSANA KEGIATAN </label>
        <input type="text" name="pelaksanaan" id="pelaksanaan" value="" class="form-control" readonly> 
    </div>

 

    <div class="form-group">
        <button type="submit" class="btn btn-primary btn-lg pull-left"> Simpan </button>
    </div>
    </form>
</div>
</div>
<script>
    $(function() {
      $('#only-number').on('keydown', '#angka_kredit', function(e){
          -1!==$
          .inArray(e.keyCode,[46,8,9,27,13,110,190]) || /65|67|86|88/
          .test(e.keyCode) && (!0 === e.ctrlKey || !0 === e.metaKey)
          || 35 <= e.keyCode && 40 >= e.keyCode || (e.shiftKey|| 48 > e.keyCode || 57 < e.keyCode)
          && (96 > e.keyCode || 105 < e.keyCode) && e.preventDefault()
      });
      

      
    })
    $('.js-source-states').select2();

    function pilihunsur(a){
        // alert(a);
        $.ajax({
            type:"POST",
            data:"id_unsur="+a,
            url:base_url+"dupak/getsubunsur",
            success:function(dt){
                $("#sub_unsur").html(dt);
            }
        })
    
    }


    function pilihsubunsur(a){
        // alert(a);
        $.ajax({
            type:"POST",
            data:"id_subunsur="+a,
            url:base_url+"dupak/getkegiatan",
            success:function(dt){
                $("#kegiatan").html(dt);
            }
        })
    
    }



</script>