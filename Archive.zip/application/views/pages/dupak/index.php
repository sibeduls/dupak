
<a class="btn btn-primary pull-left" href="<?php echo base_url() ?>dupak/add"> Tambah Data </a>

<table class="table table-striped">
<thead>
<tr>
    <th> No </th>
    <th> Unsur </th>
    <th> Subunsur </th>
    <th> Kegiatan </th>
    <th> Satuan Hasil </th>
    <th> Nilai </th>
    <th> Upload File </th>
    <th> Aksi </th>
</tr>

</thead>
<tbody> 
    <?php foreach($data as $k => $v): ?>
<tr>
    <td> <?php echo $k+1; ?> </td>
    <td><?php echo $v->nama_unsur ?> </td>
    <td><?php echo $v->nama_subunsur ?> </td>
    <td> <?php echo $v->nama_kegiatan; ?> </td>
    <td> <?php echo $v->satuan_hasil; ?> </td>
    <td> <?php echo $v->angka_kredit; ?> </td>
    <td> 
        <a href="<?php echo base_url() ?>dupak/uploadfile/<?php echo $v->id_penilaian ?>"> Klik Untuk Upload File </a>    
    

    </td>
    <td> 
    <a href="#" class="btn btn-danger"> Hapus </a>        
</td>
</tr>

    <?php endforeach ?>


</tbody>


</table>


<a class="btn btn-primary pull-left" href="<?php echo base_url() ?>dupak/add"> ajukan </a>
