<div class="row">
<a class="btn btn-primary pull-left" href="master_kegiatan/create">Tambah Data </a>

<table class="table table-striped">
<thead>
<tr>
    <th> No </th>
    <th> Kegiatan </th>
    <th> Waktu </th>
    <th> Nilai </th>
    <th> Upload File </th>
</tr>

</thead>

</table>

</div>
</div>