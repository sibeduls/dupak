<?php   


    class Biodata extends CI_Controller {

        function __construct()
        {
            parent::__construct();
            $this->load->model('Karyawan_model','karyawan');

        }


        function index(){

            $nip = $this->session->userdata('nip');

            $data['data']     = $this->karyawan->detail($nip);
            $data['template'] = 'pages/biodata/index';  
            $this->load->view('dashboard',$data);

        }

    }