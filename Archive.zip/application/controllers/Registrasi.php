<?php 

    class Registrasi extends CI_Controller {

        function __construct()
        {
            parent::__construct();  
            $this->load->model('Karyawan_model','karyawan');
        }
        function index(){

            $data = [];
            $this->load->view('register',$data);

        }
    }