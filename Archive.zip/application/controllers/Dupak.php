<?php 

    class Dupak extends CI_Controller {
        

        function __construct()
        {
            parent::__construct();
            $this->load->model('Dupak_model','model');

            $this->load->model('Master_kegiatan_model','kegiatan');
            $this->load->model('Master_unsur_model','unsur');
            $this->load->model('Master_subunsur_model','subunsur');

        }


        function index(){

            $tahun = date('Y');

            $this->load->library('pagination');
            $config['base_url'] = base_url().'dupak/index/';
            $config['total_rows'] = $this->model->total($tahun);
            $config['per_page'] = 10;
            $choice = $config["total_rows"] / $config["per_page"];
            $config["num_links"] = floor($choice);
     
            // Membuat Style pagination untuk BootStrap v4
             $config['first_link']       = 'First';
            $config['last_link']        = 'Last';
            $config['next_link']        = 'Next';
            $config['prev_link']        = 'Prev';
            $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center">';
            $config['full_tag_close']   = '</ul></nav></div>';
            $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
            $config['num_tag_close']    = '</span></li>';
            $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
            $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
            $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
            $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['prev_tagl_close']  = '</span>Next</li>';
            $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
            $config['first_tagl_close'] = '</span></li>';
            $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
            $config['last_tagl_close']  = '</span></li>';


            $from = $this->uri->segment(4);
            $this->pagination->initialize($config);
            $data['pagination'] = $this->pagination->create_links();
            $data['data'] = $this->model->data($config['per_page'],$from,$tahun);
            $data['title'] = 'Data Dupak Tahun '.$tahun;

            
            $data['template'] = 'pages/dupak/index';

            $this->load->view('dashboard',$data);

        }

        function add(){

            $data['template'] = 'pages/dupak/add';

            $data["master_unsur"] = $this->unsur->getAll();

            
            $this->load->view('dashboard',$data);


        }


        function getsubunsur(){

            $id_unsur = $this->input->post('id_unsur');
            $subunsur = $this->subunsur->get_by_unsur($id_unsur);
            echo "<option value=''>Pilih Sub Unsur </option>";
            foreach($subunsur as $k => $v){
                echo "<option value='".$v->id_subunsur."'>".$v->nama_subunsur."</option>";
            }

        }

        function getkegiatan(){

            $id_subunsur = $this->input->post('id_subunsur');
            $kegiatan = $this->kegiatan->get_by_subunsur($id_subunsur);
            // echo "<option value=''>Pilih Kegiatan </option>";
            foreach($kegiatan as $k => $v){
                if($v->parent_id == NULL OR $v->parent_id == 0){

                    if($v->kode_kegiatan == ''){
                    echo '<optgroup label="'.$v->nama_kegiatan.'">';
                    $parent_id = $v->id_kegiatan;
                    }else{
                        echo "<option value='".$v->id_kegiatan."'>".$v->nama_kegiatan."</option>";

                    }
                }

                if($v->parent_id == $parent_id){
                    echo "<option value='".$v->id_kegiatan."'>".$v->nama_kegiatan."</option>";
                }else{
                    echo "</optgroup>";
                }

            }

        }

        function proses(){

            if($this->input->post()){

                $nip = $this->session->userdata('nip');
              //  $nip = $_SESSION['nip'];
                $id_kegiatan = $this->input->post('id_kegiatan');
                $tahun = date('Y');
                $created_by = $this->session->userdata('nama_lengkap');


                $dt = array(
                    'nip' => $nip,
                    'id_kegiatan' => $id_kegiatan,
                    'tahun' => $tahun,
                    'created_by' => $created_by,
                    'created_date' => date('Y-m-d H:i:s')
                );

                $ins = $this->model->insert($dt);
                if($ins){

                    $this->session->set_flashdata('item','<div class="alert alert-info"> Data Berhasil Diinput </div>');


                }else{
                    $this->session->set_flashdata('item','<div class="alert alert-danger"> Data Gagal Diinput </div>');

                }

                redirect('dupak/add');


            }else{
                redirect('404');
            }

        }

        function uploadfile($id){

            $data['template'] = 'pages/dupak/uploadfile';
            $data['data'] = $this->model->detail($id);
            $data['files'] = $this->model->get_files($id);
            $this->load->view('dashboard',$data);

        }


        function uploadproses(){

            $id_penilaian = $this->input->post('id_penilaian');

            // print_r($_POST);
            if(!empty($_FILES['file']['name'])){

                // Set preference
                $config['upload_path'] = './files/'; 
                $config['allowed_types']        = '*';
                $config['max_size'] = '4096'; // max_size in kb
                $config['file_name'] = strtotime(date('Y-m-d H:i:s'))."_File_Dupak_".$_SESSION['nip'];
           
                //Load upload library
                $this->load->library('upload',$config); 
           
                // File upload
                if($this->upload->do_upload('file')){
                  // Get data about the file
                $dt = $this->upload->data();

                $ins = array(
                    'id_penilaian' => $id_penilaian,
                    'file_upload' => $dt['file_name'],
                    'created_by' => $_SESSION['nama_lengkap'],
                    'created_date' => date('Y-m-d H:i:s')
                );

                $insert = $this->db->insert('penilaian_file',$ins);
                if($insert){
                    
                }


                }else{
                    print_r($this->upload->display_errors());

                }
              }else{
                  echo 'empty';
              }


              redirect('dupak/uploadfile/'.$id_penilaian);



        }



    }