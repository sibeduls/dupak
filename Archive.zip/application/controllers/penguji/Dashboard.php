<?php 


    class Dashboard extends CI_Controller {

        function __construct()
        {
            parent::__construct();
        }

        function index(){
            $data['template'] = 'penguji/pages/index';

            $this->load->view('penguji/dashboard',$data);
        }

    }