<?php 

    class Dupak_model extends CI_Model {

        protected $table = 'penilaian';

        function insert($dt){

            $this->db->insert($this->table,$dt);
            return TRUE;

        }

        function data($limit,$from,$tahun){

            $nip = $_SESSION['nip'];
            $this->db->from($this->table);
            $this->db->join('master_kegiatan',$this->table.".id_kegiatan = master_kegiatan.id_kegiatan","left");
            $this->db->join('master_subunsur',"master_kegiatan.id_subunsur = master_subunsur.id_subunsur","left");
            $this->db->join('master_unsur',"master_subunsur.id_unsur = master_unsur.id_unsur","left");
            $this->db->where('nip',$nip);
             $this->db->limit($limit,$from);
            
         return $query = $this->db->get()->result();		
        }

        function detail($id_penilaian){
             $nip = $_SESSION['nip'];
            $this->db->from($this->table);
            $this->db->join('master_kegiatan',$this->table.".id_kegiatan = master_kegiatan.id_kegiatan","left");
            $this->db->join('master_subunsur',"master_kegiatan.id_subunsur = master_subunsur.id_subunsur","left");
            $this->db->join('master_unsur',"master_subunsur.id_unsur = master_unsur.id_unsur","left");
            $this->db->where('nip',$nip);
            $this->db->where('id_penilaian',$id_penilaian);
            //  $this->db->limit($limit,$from);
            
         return $query = $this->db->get()->row();
        }


        function total($tahun){
            return $this->db->get_where($this->table,array('tahun' => $tahun))->num_rows();
        }
        

        function get_files($id_penilaian){

            $a = $this->db->get_where('penilaian_file',array('id_penilaian' => $id_penilaian))->result();
            return $a;

        }
        
        


    }