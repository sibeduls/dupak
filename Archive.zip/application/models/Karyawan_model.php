<?php   

    class Karyawan_model extends CI_Model {

        protected $table = 'karyawan';


        function detail($nip){

            $this->db->from($this->table);
            $this->db->join('master_golongan',$this->table.'.id_golongan = master_golongan.id_golongan','left');
            $this->db->join('master_tipefungsional',$this->table.'.id_tipefungsional = master_tipefungsional.id_tipefungsional','left');
            $this->db->where('nip',$nip);
            $query = $this->db->get();
            $run = $query->row();
            return $run;

        }


        function data($limit,$from){


     $this->db->from($this->table);
            $this->db->join('master_golongan',$this->table.'.id_golongan = master_golongan.id_golongan','left');
            $this->db->join('master_tipefungsional',$this->table.'.id_tipefungsional = master_tipefungsional.id_tipefungsional','left');
            // $this->db->where('nip',$nip);
                $this->db->limit($limit,$from);
            
         return $query = $this->db->get()->result();		
        }

        function total(){
            return $this->db->get($this->table)->num_rows();
        }



    }