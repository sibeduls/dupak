<?php 


    function cek_login(){

        $CI =& get_instance();
        if($CI->session->userdata('login') != TRUE){
            redirect('login');
        }else{
            return TRUE;
        }
    }


    function is_superadmin(){
        cek_login();
        if($CI->session->userdata('id_level') == 1){
            return TRUE;
        }else{
            redirect('404');
        }

    }